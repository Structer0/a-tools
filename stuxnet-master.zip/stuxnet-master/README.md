stuxnet
=======

Eventually, this will be a comprehensive decompilation of Stuxnet's dropper. 

Eventually.



Initial base provided by https://github.com/Christian-Roggia/open-myrtus
	Note: The above repo has slightly cleaner source code( for now ), and includes the rootkit.
